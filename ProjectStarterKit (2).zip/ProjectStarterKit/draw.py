# TODO: Your header

import cmpt120image

def recolor_image(img, color):
  # TODO: Add your code here
  pass

def minify(img):
  # TODO: Add your code here
  pass
  
def mirror(img):
  # TODO: Add your code here
  pass
  
def draw_item(canvas, img, row, col):
  # TODO: Add your code here
  pass
  
def distribute_items(canvas, img, n):
  # TODO: Add your code here
  pass
